"""
config.py
---------
Central configuration for the SP-anchored MLB model.

All magic numbers live here. Do not scatter thresholds across modules; change
them here and re-backtest. The defaults below encode the v12-CONVICTION
framework from prior model iterations.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


# ---------------------------------------------------------------------------
# Feature weighting — Stage 1 (F5 / Starting Pitcher Anchor)
# ---------------------------------------------------------------------------
# These weights are *prior* weights used for feature scaling and sanity checks
# in the engineered-feature composite score. The gradient-boosted model learns
# its own feature importances; these act as a sanity anchor and drive the
# rule-based conviction filter.

SP_WEIGHTS: Dict[str, float] = {
    # Starting pitcher quality dominates F5 prediction.
    "sp_xera_gap": 0.35,        # (opp_SP_xERA - our_SP_xERA), larger = bigger edge
    "sp_xwoba_allowed_gap": 0.25,
    "sp_k_bb_pct_gap": 0.15,
    "sp_siera_gap": 0.15,
    "sp_recent_form_gap": 0.10,  # last-3-starts xFIP, fade recency over-reactions
}
assert abs(sum(SP_WEIGHTS.values()) - 1.0) < 1e-6, "SP weights must sum to 1.0"


# ---------------------------------------------------------------------------
# Feature weighting — Stage 2 (Full Game)
# ---------------------------------------------------------------------------
# Stage 2 takes Stage 1 F5 output as an input AND adds these. The high weight
# on f5_model_output is the architectural guarantee against SP dilution: the
# starting pitcher's contribution is already "locked in" before we layer
# offense/bullpen/context on top.

FULL_GAME_WEIGHTS: Dict[str, float] = {
    "f5_model_output": 0.60,     # hard anchor — SP signal survives
    "bullpen_siera_gap": 0.12,
    "bullpen_fatigue_gap": 0.08,
    "team_wrcplus_gap": 0.10,
    "handedness_split_edge": 0.05,
    "park_hr_factor": 0.03,
    "catcher_framing_gap": 0.02,
}
assert abs(sum(FULL_GAME_WEIGHTS.values()) - 1.0) < 1e-6, "Full-game weights must sum to 1.0"


# ---------------------------------------------------------------------------
# v12-CONVICTION filter thresholds
# ---------------------------------------------------------------------------
# A pick is only "live" if multiple independent signals converge. Single-signal
# edges tend to be noise. These thresholds are calibrated from prior backtests.

@dataclass(frozen=True)
class ConvictionThresholds:
    xera_gap_min: float = 0.75        # F1: opp SP xERA - our SP xERA (runs/9)
    xwoba_gap_min: float = 0.020      # F2: team xwOBA gap
    swing_take_gap_min: float = 15.0  # F3: runs_all swing/take gap (per-PA*1000 scaled)
    pitcher_luck_max: float = -1.0    # F4: ERA - xERA; negative = lucky, due for regression


CONVICTION = ConvictionThresholds()


# Conviction score -> bet tier mapping.
# The tier maps to a size multiplier applied to the Kelly stake.
TIER_SIZES: Dict[str, float] = {
    "DIAMOND": 1.00,   # 3+ signals fire
    "PLATINUM": 0.60,  # 2 signals fire
    "GOLD": 0.33,      # 1 signal fires AND it is F4 (regression)
    "SKIP": 0.00,      # 0 signals — no bet regardless of nominal edge
}


# ---------------------------------------------------------------------------
# Market / EV thresholds
# ---------------------------------------------------------------------------
MIN_EDGE_PCT: float = 0.03            # 3% EV floor after devigging
MIN_MODEL_PROB: float = 0.48          # avoid extreme longshots
MAX_MODEL_PROB: float = 0.72          # avoid extreme chalk (value compression)
KELLY_FRACTION: float = 0.25          # quarter-Kelly to control variance
MAX_DAILY_RISK_UNITS: float = 7.0     # v12 structural cap per slate


# ---------------------------------------------------------------------------
# Bullpen fatigue rules
# ---------------------------------------------------------------------------
BULLPEN_FATIGUE_LOOKBACK_DAYS: int = 3
BULLPEN_PITCHES_FATIGUE_THRESHOLD: int = 35  # cumulative pitches over lookback
BULLPEN_BACKTOBACK_APPEARANCES: int = 2      # consecutive-day appearances = unavailable


# ---------------------------------------------------------------------------
# Environmental overlays (applied post-model)
# ---------------------------------------------------------------------------
# Ball carry: +3.5 ft per +10°F above a 70°F baseline.
TEMP_BASELINE_F: float = 70.0
CARRY_FT_PER_10F: float = 3.5

# Umpire 'Matthew Effect' — elite starters get zone expansion.
UMP_ACE_ERA_PLUS_THRESHOLD: float = 125.0
UMP_ACE_ZONE_EXPANSION: float = 0.05           # 5% K-rate bump for aces
UMP_DIVISIONAL_DAMPENING: float = 0.5          # halve the expansion in intra-division

# Travel & getaway-day
TRAVEL_TZ_PENALTY: float = -0.10               # 10% offensive haircut after 2+ TZ travel
BACKUP_CATCHER_SP_PENALTY: float = -0.05       # 5% pitcher efficiency haircut


# ---------------------------------------------------------------------------
# Model hyperparameters
# ---------------------------------------------------------------------------
XGB_PARAMS_F5: Dict = {
    "objective": "binary:logistic",
    "eval_metric": "logloss",
    "max_depth": 5,
    "learning_rate": 0.04,
    "n_estimators": 600,
    "min_child_weight": 8,
    "subsample": 0.85,
    "colsample_bytree": 0.80,
    "reg_lambda": 1.5,
    "random_state": 42,
    "tree_method": "hist",
}

XGB_PARAMS_FULL: Dict = {
    "objective": "binary:logistic",
    "eval_metric": "logloss",
    "max_depth": 4,            # shallower — Stage 2 should mostly refine Stage 1
    "learning_rate": 0.03,
    "n_estimators": 500,
    "min_child_weight": 10,
    "subsample": 0.85,
    "colsample_bytree": 0.75,
    "reg_lambda": 2.0,
    "random_state": 42,
    "tree_method": "hist",
}


# ---------------------------------------------------------------------------
# Monotonic constraints — enforce domain knowledge on the gradient booster.
# XGBoost accepts a tuple (1, -1, 0) per feature: 1 = non-decreasing in target,
# -1 = non-increasing, 0 = no constraint. This is the formal mechanism that
# prevents the model from learning absurd relationships during overfitting.
# ---------------------------------------------------------------------------
F5_MONOTONE: Dict[str, int] = {
    "sp_xera_gap": 1,              # bigger gap (opp worse) -> higher win prob
    "sp_xwoba_allowed_gap": 1,
    "sp_k_bb_pct_gap": 1,
    "sp_siera_gap": 1,
    "sp_recent_form_gap": 1,
}

FULL_MONOTONE: Dict[str, int] = {
    "f5_model_output": 1,
    "bullpen_siera_gap": 1,
    "team_wrcplus_gap": 1,
    "bullpen_fatigue_gap": -1,     # more fatigued opp bullpen -> we win more
}


# ---------------------------------------------------------------------------
# Data source paths / API config
# ---------------------------------------------------------------------------
@dataclass
class DataConfig:
    statcast_cache_dir: str = "./data/statcast_cache"
    odds_cache_dir: str = "./data/odds_cache"
    odds_api_base: str = "https://api.the-odds-api.com/v4"
    odds_sport: str = "baseball_mlb"
    odds_regions: str = "us"
    odds_markets: str = "h2h,totals"
    odds_bookmakers: List[str] = field(default_factory=lambda: [
        "draftkings", "fanduel", "betmgm", "caesars", "pinnacle",
    ])


DATA = DataConfig()
