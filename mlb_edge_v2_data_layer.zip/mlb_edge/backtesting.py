"""
backtesting.py
--------------
Simulate the full pipeline on historical data with zero future leakage.

Contract:
  - `fit_and_predict_walk_forward` retrains at each fold boundary and predicts
    ONLY the held-out future games. There is no cross-fold contamination.
  - Kelly stakes are computed using the bankroll *at the time of the bet*.
  - Every bet that passes the conviction + edge filter is recorded with its
    resolved outcome so you can slice P&L by tier, by signal family, by
    market (home vs away), by month, etc.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

from .config import KELLY_FRACTION, MAX_DAILY_RISK_UNITS
from .edge_calculator import (
    american_to_decimal,
    expected_value,
    kelly_stake,
    score_conviction,
)
from .market_analysis import american_to_implied, shin
from .model import (
    F5_FEATURES,
    FULL_FEATURES_EXTRA,
    TrainedModel,
    predict,
    time_series_cv,
    train_stage1_f5,
    train_stage2_full,
)

log = logging.getLogger(__name__)


@dataclass
class BacktestResult:
    bets: pd.DataFrame
    equity_curve: pd.DataFrame
    summary: Dict


def fit_and_predict_walk_forward(df: pd.DataFrame,
                                 n_splits: int = 6) -> pd.DataFrame:
    """
    Walk-forward training. For each time-series fold:
      1. Fit Stage 1 on train, Stage 2 on train.
      2. Predict on valid.
      3. Concatenate all valid predictions into a single DataFrame.

    The caller can then run the edge/bet sim on the resulting frame.
    """
    out_frames = []
    for fold_idx, (tr, va) in enumerate(time_series_cv(df, n_splits=n_splits)):
        log.info("Fold %d: train %d, valid %d", fold_idx, len(tr), len(va))
        try:
            m1 = train_stage1_f5(tr, valid=va)
            m2 = train_stage2_full(tr, m1, valid=va)
        except Exception as e:
            log.error("Fold %d training failed: %s", fold_idx, e)
            continue
        preds = predict(m1, m2, va)
        preds["fold"] = fold_idx
        out_frames.append(preds)
    if not out_frames:
        return pd.DataFrame()
    return pd.concat(out_frames, ignore_index=True)


def simulate_roi(preds: pd.DataFrame,
                 odds: pd.DataFrame,
                 start_bankroll: float = 100.0,
                 min_edge: float = 0.03) -> BacktestResult:
    """
    Simulate Kelly-sized betting on the predictions.

    preds must contain:
        game_id, game_date, model_prob, home_team, away_team, home_win,
        plus all conviction-signal columns.

    odds must contain (long form):
        game_id, market=h2h, outcome (team name), price (American)
    """
    if preds.empty:
        return BacktestResult(pd.DataFrame(), pd.DataFrame(), {"note": "empty preds"})

    h2h = odds[odds["market"] == "h2h"]
    wide = (h2h.pivot_table(index="game_id", columns="outcome",
                            values="price", aggfunc="median")
            .reset_index())
    df = preds.merge(wide, on="game_id", how="left")

    bankroll = start_bankroll
    bets: List[Dict] = []
    equity_points: List[Dict] = []
    daily_risk: Dict = {}

    for _, r in df.sort_values("game_date").iterrows():
        home_price = r.get(r["home_team"])
        away_price = r.get(r["away_team"])
        if pd.isna(home_price) or pd.isna(away_price):
            continue

        p_home_raw = american_to_implied(home_price)
        p_away_raw = american_to_implied(away_price)
        p_home_fair, _ = shin(p_home_raw, p_away_raw)

        # Pick side aligned with the model
        p_model = r["model_prob"]
        if p_model >= 0.5:
            side, price, fair, prob = "home", home_price, p_home_fair, p_model
            side_team = r["home_team"]
        else:
            side, price, fair, prob = "away", away_price, 1 - p_home_fair, 1 - p_model
            side_team = r["away_team"]

        if pd.isna(fair):
            continue
        edge = prob - fair
        if edge < min_edge:
            continue

        # Conviction
        perspective = r.copy()
        if side == "away":
            for col in ["sp_xera_gap", "team_woba_gap", "sp_k_bb_pct_gap",
                        "sp_siera_gap", "sp_fip_gap"]:
                if col in perspective:
                    perspective[col] = -perspective[col]
            perspective["home_sp_luck"], perspective["away_sp_luck"] = (
                perspective.get("away_sp_luck"), perspective.get("home_sp_luck"),
            )
        conviction = score_conviction(perspective)
        from .config import TIER_SIZES
        mult = TIER_SIZES[conviction.tier]
        if mult == 0:
            continue

        dec = american_to_decimal(price)
        stake_frac = kelly_stake(prob, dec, fraction=KELLY_FRACTION) * mult
        stake = stake_frac * bankroll
        if stake <= 0:
            continue

        # Daily risk cap (in bankroll-normalized "units")
        day_key = pd.Timestamp(r["game_date"]).date()
        used = daily_risk.get(day_key, 0.0)
        # Translate MAX_DAILY_RISK_UNITS (in "u") assuming 1u = 1% of starting bankroll
        cap_dollars = (MAX_DAILY_RISK_UNITS / 100.0) * start_bankroll
        remaining = max(0.0, cap_dollars - used)
        if remaining <= 0:
            continue
        stake = min(stake, remaining)
        daily_risk[day_key] = used + stake

        # Resolve
        won = (r["home_win"] == 1 and side == "home") or \
              (r["home_win"] == 0 and side == "away")
        pnl = stake * (dec - 1) if won else -stake
        bankroll += pnl

        bets.append({
            "game_id":   r["game_id"],
            "game_date": r["game_date"],
            "side":      side,
            "team":      side_team,
            "price":     price,
            "decimal":   dec,
            "prob":      prob,
            "fair":      fair,
            "edge_pp":   edge * 100,
            "ev":        expected_value(prob, dec),
            "tier":      conviction.tier,
            "signals":   ", ".join(conviction.signals_fired),
            "stake":     stake,
            "won":       won,
            "pnl":       pnl,
            "bankroll":  bankroll,
        })
        equity_points.append({"game_date": r["game_date"], "bankroll": bankroll})

    bets_df = pd.DataFrame(bets)
    eq_df = pd.DataFrame(equity_points)

    if bets_df.empty:
        return BacktestResult(bets_df, eq_df, {"note": "no bets"})

    summary = {
        "n_bets": len(bets_df),
        "win_rate": float(bets_df["won"].mean()),
        "total_pnl": float(bets_df["pnl"].sum()),
        "roi_pct": float(bets_df["pnl"].sum() / bets_df["stake"].sum() * 100),
        "starting_bankroll": start_bankroll,
        "ending_bankroll": bankroll,
        "max_drawdown_pct": float(_max_drawdown_pct(eq_df["bankroll"]) * 100)
                            if not eq_df.empty else 0.0,
        "by_tier": bets_df.groupby("tier").agg(
            n=("won", "size"),
            wr=("won", "mean"),
            pnl=("pnl", "sum"),
            roi=("pnl", lambda s: s.sum() / max(bets_df.loc[s.index, "stake"].sum(), 1e-9)),
        ).to_dict(),
    }
    return BacktestResult(bets_df, eq_df, summary)


def _max_drawdown_pct(equity: pd.Series) -> float:
    if equity.empty:
        return 0.0
    running_max = equity.cummax()
    drawdown = (equity - running_max) / running_max
    return float(drawdown.min())
