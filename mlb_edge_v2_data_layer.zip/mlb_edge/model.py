"""
model.py
--------
Two-stage gradient-boosted model.

Stage 1 (F5 model):
    Inputs  : ONLY starting-pitcher gap features.
    Target  : home team leads after 5 innings (binary).
    Rationale: Lock in the SP signal before bullpen/offense variables have a
               chance to dilute it in Stage 2's feature space.

Stage 2 (Full game model):
    Inputs  : Stage 1 predicted probability + offense + bullpen + context.
    Target  : home team wins the game (binary).
    Rationale: Stage 1's output is a strong anchor feature. Because it is
               derived purely from SP data, Stage 2 cannot "unlearn" the SP
               effect even if it overfits to a noisy offensive stat.

Monotonic constraints enforce that, e.g., a bigger SP xERA gap in our favor
cannot decrease our predicted win probability. This is a formal guardrail
against overfitting-driven nonsense splits.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import joblib
import numpy as np
import pandas as pd

import xgboost as xgb
from sklearn.metrics import brier_score_loss, log_loss, roc_auc_score
from sklearn.model_selection import TimeSeriesSplit

from .config import F5_MONOTONE, FULL_MONOTONE, XGB_PARAMS_F5, XGB_PARAMS_FULL

log = logging.getLogger(__name__)


F5_FEATURES: List[str] = [
    "sp_xera_gap", "sp_xwoba_allowed_gap", "sp_fip_gap", "sp_siera_gap",
    "sp_k_bb_pct_gap", "sp_recent_form_gap", "sp_hardhit_gap", "sp_stamina_gap",
]

FULL_FEATURES_EXTRA: List[str] = [
    "f5_model_output",
    "team_wrcplus_gap", "team_woba_gap", "team_bbk_gap", "team_hardhit_gap",
    "bullpen_siera_gap", "bullpen_fatigue_gap",
    "park_runs_factor", "park_hr_factor",
    "home_ump_boost", "away_ump_boost",
    "home_catcher_penalty", "away_catcher_penalty",
    "home_sp_luck", "away_sp_luck",
    "is_divisional", "tz_diff", "is_opener", "is_quick_turnaround",
]


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------
def _monotone_tuple(features: List[str], mono_map: Dict[str, int]) -> str:
    """XGBoost expects a parenthesized string like '(1,1,0,-1,0,...)'."""
    return "(" + ",".join(str(mono_map.get(f, 0)) for f in features) + ")"


def _xy_split(df: pd.DataFrame, feature_cols: List[str],
              target_col: str) -> Tuple[pd.DataFrame, pd.Series]:
    X = df[feature_cols].copy()
    y = df[target_col].astype(int)
    # XGBoost handles NaNs natively via default direction learning.
    return X, y


# ---------------------------------------------------------------------------
# Trainers
# ---------------------------------------------------------------------------
@dataclass
class TrainedModel:
    booster: xgb.XGBClassifier
    feature_cols: List[str]
    metadata: Dict


def train_stage1_f5(train: pd.DataFrame,
                    valid: Optional[pd.DataFrame] = None) -> TrainedModel:
    """
    Fit the F5 model. Target column must be `home_f5_win` (home team leads
    after 5 innings, including ties broken in favor of home or dropped).
    """
    feats = [c for c in F5_FEATURES if c in train.columns]
    if len(feats) < 3:
        raise ValueError(f"Too few SP features available; have {feats}")

    params = {**XGB_PARAMS_F5, "monotone_constraints": _monotone_tuple(feats, F5_MONOTONE)}
    model = xgb.XGBClassifier(**params)

    X_tr, y_tr = _xy_split(train, feats, "home_f5_win")
    eval_set = None
    if valid is not None and not valid.empty:
        X_va, y_va = _xy_split(valid, feats, "home_f5_win")
        eval_set = [(X_va, y_va)]

    model.fit(X_tr, y_tr, eval_set=eval_set, verbose=False)
    meta = {
        "n_train": len(X_tr),
        "n_valid": 0 if valid is None else len(valid),
        "train_auc": roc_auc_score(y_tr, model.predict_proba(X_tr)[:, 1]),
    }
    if eval_set:
        meta["valid_auc"] = roc_auc_score(y_va, model.predict_proba(X_va)[:, 1])
        meta["valid_logloss"] = log_loss(y_va, model.predict_proba(X_va)[:, 1])
    return TrainedModel(model, feats, meta)


def train_stage2_full(train: pd.DataFrame,
                      stage1: TrainedModel,
                      valid: Optional[pd.DataFrame] = None) -> TrainedModel:
    """
    Fit the full-game model. We engineer `f5_model_output` into the training
    frame using Stage 1 predictions BEFORE fitting Stage 2. This means Stage 2
    sees the SP signal as a single dense feature rather than scattered across
    eight correlated gap columns — preventing dilution.
    """
    train = train.copy()
    train["f5_model_output"] = stage1.booster.predict_proba(
        train[stage1.feature_cols].values
    )[:, 1]

    if valid is not None and not valid.empty:
        valid = valid.copy()
        valid["f5_model_output"] = stage1.booster.predict_proba(
            valid[stage1.feature_cols].values
        )[:, 1]

    feats = [c for c in FULL_FEATURES_EXTRA if c in train.columns]
    params = {**XGB_PARAMS_FULL, "monotone_constraints": _monotone_tuple(feats, FULL_MONOTONE)}
    model = xgb.XGBClassifier(**params)

    X_tr, y_tr = _xy_split(train, feats, "home_win")
    eval_set = None
    if valid is not None and not valid.empty:
        X_va, y_va = _xy_split(valid, feats, "home_win")
        eval_set = [(X_va, y_va)]

    model.fit(X_tr, y_tr, eval_set=eval_set, verbose=False)
    meta = {
        "n_train": len(X_tr),
        "n_valid": 0 if valid is None else len(valid),
        "train_auc": roc_auc_score(y_tr, model.predict_proba(X_tr)[:, 1]),
    }
    if eval_set:
        meta["valid_auc"] = roc_auc_score(y_va, model.predict_proba(X_va)[:, 1])
        meta["valid_brier"] = brier_score_loss(y_va, model.predict_proba(X_va)[:, 1])
        meta["valid_logloss"] = log_loss(y_va, model.predict_proba(X_va)[:, 1])
    return TrainedModel(model, feats, meta)


# ---------------------------------------------------------------------------
# Inference
# ---------------------------------------------------------------------------
def predict(stage1: TrainedModel, stage2: TrainedModel,
            games: pd.DataFrame) -> pd.DataFrame:
    """Return home-team win probabilities (+ F5 probability) for a slate."""
    out = games.copy()
    out["f5_prob"] = stage1.booster.predict_proba(
        games[stage1.feature_cols].values
    )[:, 1]
    enriched = out.copy()
    enriched["f5_model_output"] = out["f5_prob"]
    out["model_prob"] = stage2.booster.predict_proba(
        enriched[stage2.feature_cols].values
    )[:, 1]
    return out


# ---------------------------------------------------------------------------
# Time-series CV wrapper
# ---------------------------------------------------------------------------
def time_series_cv(df: pd.DataFrame, n_splits: int = 5) -> List[Tuple[pd.DataFrame, pd.DataFrame]]:
    """
    Split by `game_date` so the validation set is always future-dated relative
    to training. Essential for a sports model: random CV leaks information.
    """
    df = df.sort_values("game_date").reset_index(drop=True)
    tscv = TimeSeriesSplit(n_splits=n_splits)
    out = []
    for tr_idx, va_idx in tscv.split(df):
        out.append((df.iloc[tr_idx].reset_index(drop=True),
                    df.iloc[va_idx].reset_index(drop=True)))
    return out


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------
def save(stage1: TrainedModel, stage2: TrainedModel, path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"stage1": stage1, "stage2": stage2}, path)


def load(path: str) -> Tuple[TrainedModel, TrainedModel]:
    bundle = joblib.load(path)
    return bundle["stage1"], bundle["stage2"]


# ---------------------------------------------------------------------------
# Feature importance helpers
# ---------------------------------------------------------------------------
def importance_table(model: TrainedModel, kind: str = "gain") -> pd.DataFrame:
    """Pretty feature-importance table ordered descending."""
    raw = model.booster.get_booster().get_score(importance_type=kind)
    rows = [{"feature": f, "importance": raw.get(f, 0.0)} for f in model.feature_cols]
    return pd.DataFrame(rows).sort_values("importance", ascending=False).reset_index(drop=True)
