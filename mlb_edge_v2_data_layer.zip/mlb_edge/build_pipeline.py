"""
build_pipeline.py
-----------------
The glue that turns raw Statcast + odds + weather into a model-ready frame.

Three entry points:
  - build_historical_frame(season, through=None)
        Returns DataFrame ready for model training / backtesting.
  - build_slate_frame(day)
        Returns DataFrame of today's games for live prediction.
  - build_odds_frame(season, through=None)
        Returns historical odds long-format frame for backtest simulation.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from . import data_ingestion as di
from . import point_in_time as pit
from . import weather as wx
from . import stadiums as stadiums_mod
from .stadiums import (DIVISIONS, STADIUMS, TEAM_ALIASES, get_stadium,
                       is_divisional, normalize_team, tz_offset_hours)
from .config import TEMP_BASELINE_F, CARRY_FT_PER_10F

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Game-level aggregation from raw Statcast
# ---------------------------------------------------------------------------
def _game_outcomes(statcast_df: pd.DataFrame) -> pd.DataFrame:
    """
    One row per game_pk with final score + F5 score.
    """
    if statcast_df.empty:
        return pd.DataFrame()

    # Final scores from last pitch of the game
    fin = statcast_df.sort_values(["game_pk", "inning", "at_bat_number", "pitch_number"])
    finals = fin.groupby("game_pk").tail(1)[
        ["game_pk", "game_date", "home_team", "away_team",
         "post_home_score", "post_away_score"]
    ].rename(columns={"post_home_score": "home_score",
                      "post_away_score": "away_score"})

    # F5 score = max bat_score + fld_score in innings 1-5
    f5 = statcast_df[statcast_df["inning"] <= 5].copy()
    if not f5.empty:
        # Score accumulates in post_*_score columns; take max per game
        f5_agg = f5.groupby("game_pk").agg(
            home_f5_score=("post_home_score", "max"),
            away_f5_score=("post_away_score", "max"),
        ).reset_index()
        finals = finals.merge(f5_agg, on="game_pk", how="left")
    else:
        finals["home_f5_score"] = np.nan
        finals["away_f5_score"] = np.nan

    finals["home_win"] = (finals["home_score"] > finals["away_score"]).astype(int)
    finals["home_f5_win"] = (finals["home_f5_score"] > finals["away_f5_score"]).astype(int)
    finals["game_date"] = pd.to_datetime(finals["game_date"])

    return finals


# ---------------------------------------------------------------------------
# Historical frame (training + backtesting)
# ---------------------------------------------------------------------------
def build_historical_frame(season: int,
                           through: Optional[date] = None,
                           include_weather: bool = True) -> pd.DataFrame:
    """
    Build a complete per-game feature frame for `season`.

    This is the expensive function. First run pulls Statcast (1-2 min per
    month of games) and weather (a few hundred API calls). Subsequent runs
    are cache hits and take seconds.

    Returns one row per game with:
      - All SP gap features
      - All team offensive gap features
      - Bullpen gap + fatigue
      - Park + weather
      - Context flags (divisional, tz, catcher unknown = neutral)
      - Targets: home_win, home_f5_win
    """
    log.info("Building historical frame for season %d%s",
             season, f" through {through}" if through else "")

    # 1. Pull Statcast
    if through:
        sc = di.fetch_ytd_statcast(through)
    else:
        sc = di.fetch_season_statcast(season)
    if sc.empty:
        log.error("No Statcast data for season %d", season)
        return pd.DataFrame()

    # Keep only regular-season games, and only the requested season
    sc["game_date"] = pd.to_datetime(sc["game_date"])
    sc = sc[sc["game_date"].dt.year == season]
    if through:
        sc = sc[sc["game_date"].dt.date <= through]

    log.info("Statcast pitches loaded: %d", len(sc))

    # 2. Infer starters
    starters_by_team = pit.infer_starters_by_team(sc)

    # 3. Per-game outcomes
    outcomes = _game_outcomes(sc)
    if outcomes.empty:
        return pd.DataFrame()
    log.info("Games in frame: %d", len(outcomes))

    # 4. For each game, compute point-in-time features
    rows = []
    for i, g in outcomes.iterrows():
        if i % 100 == 0 and i > 0:
            log.info("  feature-building: %d/%d games", i, len(outcomes))

        starters = pit.get_game_starters(sc, g["game_pk"])
        if starters["home_sp"] is None or starters["away_sp"] is None:
            continue

        row = _build_game_row(
            sc=sc,
            game_pk=g["game_pk"],
            game_date=g["game_date"],
            home_team=g["home_team"],
            away_team=g["away_team"],
            home_sp_id=starters["home_sp"],
            away_sp_id=starters["away_sp"],
            starters_by_team=starters_by_team,
            include_weather=include_weather,
        )
        row["home_win"]    = g["home_win"]
        row["home_f5_win"] = g["home_f5_win"]
        rows.append(row)

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows)
    log.info("Feature frame complete: %d games, %d columns", len(df), len(df.columns))
    return df


# ---------------------------------------------------------------------------
# Slate frame (live prediction)
# ---------------------------------------------------------------------------
def build_slate_frame(day: date,
                      include_weather: bool = True) -> pd.DataFrame:
    """
    Build per-game features for `day`'s slate.

    Pulls probable pitchers from MLB Stats API, joins against YTD Statcast
    for point-in-time stats, fetches weather per stadium.
    """
    log.info("Building slate frame for %s", day)

    schedule = di.fetch_schedule_mlb_api(day)
    if not schedule:
        log.warning("No games scheduled for %s", day)
        return pd.DataFrame()

    # Pull YTD Statcast (up to yesterday — today's games aren't in Statcast yet)
    sc = di.fetch_ytd_statcast(day - timedelta(days=1))
    if sc.empty:
        log.error("No Statcast data available for YTD stats")
        return pd.DataFrame()
    sc["game_date"] = pd.to_datetime(sc["game_date"])

    starters_by_team = pit.infer_starters_by_team(sc)

    rows = []
    for g in schedule:
        # Skip games without probable pitchers announced yet
        if not g.get("home_sp_id") or not g.get("away_sp_id"):
            log.warning("Skipping game %s: probable pitcher not announced", g.get("game_pk"))
            continue

        home = normalize_team(g["home_team"])
        away = normalize_team(g["away_team"])

        row = _build_game_row(
            sc=sc,
            game_pk=g["game_pk"],
            game_date=pd.Timestamp(day),
            home_team=home,
            away_team=away,
            home_sp_id=g["home_sp_id"],
            away_sp_id=g["away_sp_id"],
            starters_by_team=starters_by_team,
            include_weather=include_weather,
            game_time_utc=pd.to_datetime(g.get("game_date")),
        )
        rows.append(row)

    return pd.DataFrame(rows) if rows else pd.DataFrame()


# ---------------------------------------------------------------------------
# Single-game row assembly — the core join
# ---------------------------------------------------------------------------
def _build_game_row(*, sc: pd.DataFrame, game_pk: int,
                    game_date: pd.Timestamp,
                    home_team: str, away_team: str,
                    home_sp_id: int, away_sp_id: int,
                    starters_by_team: Dict[str, set],
                    include_weather: bool = True,
                    game_time_utc: Optional[pd.Timestamp] = None) -> Dict:
    """Assemble one model-ready row."""
    # SP point-in-time stats
    home_sp = pit.pitcher_as_of(sc, home_sp_id, game_date)
    away_sp = pit.pitcher_as_of(sc, away_sp_id, game_date)

    # Team offense point-in-time
    home_off = pit.team_batting_as_of(sc, home_team, game_date)
    away_off = pit.team_batting_as_of(sc, away_team, game_date)

    # Bullpen aggregates
    home_bp  = pit.bullpen_as_of(sc, home_team, game_date, starters_by_team)
    away_bp  = pit.bullpen_as_of(sc, away_team, game_date, starters_by_team)
    home_fat = pit.bullpen_fatigue_as_of(sc, home_team, game_date, starters_by_team)
    away_fat = pit.bullpen_fatigue_as_of(sc, away_team, game_date, starters_by_team)

    # Park
    stadium = get_stadium(home_team)
    park_runs = stadium["runs"] / 100.0
    park_hr   = stadium["hr"] / 100.0

    # Weather (if enabled & stadium known)
    temp_f, wind_out = TEMP_BASELINE_F, 0.0
    if include_weather and stadium["lat"] != 0.0:
        when = game_time_utc if game_time_utc is not None else pd.Timestamp(game_date) + pd.Timedelta(hours=19)
        w = wx.get_weather(stadium["lat"], stadium["lon"], when.to_pydatetime())
        temp_f = w["temp_f"]
        wind_out = wx.wind_out_to_cf_mph(w["wind_mph"], w["wind_deg"], 0.0)

    # Weather carry adjustment to HR factor
    temp_bump = CARRY_FT_PER_10F * (temp_f - TEMP_BASELINE_F) / 10.0
    wind_bump = max(wind_out, 0.0) * 1.0
    park_hr_adj = park_hr * (1.0 + 0.004 * (temp_bump + wind_bump))

    # Context
    divisional = is_divisional(home_team, away_team)
    tz_diff = tz_offset_hours(away_team, home_team)  # travel cost for away team

    # Build gap features from perspective of HOME team
    # (positive gap = home advantage)
    def inv(a, b, k): return (b.get(k) or np.nan) - (a.get(k) or np.nan)
    def fwd(a, b, k): return (a.get(k) or np.nan) - (b.get(k) or np.nan)

    return {
        "game_id":   game_pk,
        "game_date": pd.Timestamp(game_date),
        "home_team": home_team,
        "away_team": away_team,
        # --- Stage 1 features: SP gaps ---
        "sp_xera_gap":           inv(home_sp, away_sp, "sp_xera"),
        "sp_xwoba_allowed_gap":  inv(home_sp, away_sp, "sp_xwoba_allowed"),
        "sp_k_bb_pct_gap":       fwd(home_sp, away_sp, "sp_k_bb_pct"),
        "sp_siera_gap":          inv(home_sp, away_sp, "sp_siera"),
        "sp_fip_gap":            inv(home_sp, away_sp, "sp_fip"),
        "sp_recent_form_gap":    inv(home_sp, away_sp, "sp_recent_xfip"),
        "sp_hardhit_gap":        inv(home_sp, away_sp, "sp_hardhit_pct_allowed"),
        "sp_stamina_gap":        fwd(home_sp, away_sp, "sp_ip_per_start"),
        # --- Stage 2 features: team offense + bullpen ---
        "team_wrcplus_gap":      fwd(home_off, away_off, "team_wrc_plus"),
        "team_woba_gap":         fwd(home_off, away_off, "team_xwoba"),
        "team_bbk_gap":          (fwd(home_off, away_off, "team_bb_pct")
                                  - fwd(home_off, away_off, "team_k_pct")),
        "team_hardhit_gap":      fwd(home_off, away_off, "team_hardhit_pct"),
        "bullpen_siera_gap":     inv(home_bp, away_bp, "bullpen_xera"),
        "bullpen_fatigue_gap":   home_fat - away_fat,
        "park_runs_factor":      park_runs,
        "park_hr_factor":        park_hr_adj,
        "home_ump_boost":        1.0,  # not implemented per-game yet
        "away_ump_boost":        1.0,
        "home_catcher_penalty":  1.0,  # not implemented (no backup-catcher feed)
        "away_catcher_penalty":  1.0,
        "home_sp_luck":          home_sp.get("sp_era_xera_gap", np.nan),
        "away_sp_luck":          away_sp.get("sp_era_xera_gap", np.nan),
        # --- Conviction filter inputs ---
        "swing_take_gap":        fwd(home_off, away_off, "team_swing_take"),
        # --- Context ---
        "is_divisional":         int(divisional),
        "tz_diff":               int(tz_diff),
        "is_opener":             0,
        "is_quick_turnaround":   0,
        "temp_f":                temp_f,
        "wind_out_mph":          wind_out,
    }


# ---------------------------------------------------------------------------
# Historical odds frame
# ---------------------------------------------------------------------------
def build_odds_frame(season: int,
                     through: Optional[date] = None,
                     snapshot_hour_utc: int = 22) -> pd.DataFrame:
    """
    Pull historical odds for a season from the-odds-api.

    Matching to games: the-odds-api uses team names as strings; we normalize
    both to our 3-letter abbreviations, then join on (home_team, away_team,
    commence_date) against the features frame.
    """
    client = di.OddsClient()
    raw = client.historical_for_season(season, through=through,
                                       snapshot_hour_utc=snapshot_hour_utc)
    if raw.empty:
        return raw

    raw["home_team_abbr"] = raw["home_team"].apply(normalize_team)
    raw["away_team_abbr"] = raw["away_team"].apply(normalize_team)
    raw["commence_date"] = pd.to_datetime(raw["commence_time"]).dt.date

    # Keep only H2H (moneyline) for now — totals handled separately later
    h2h = raw[raw["market"] == "h2h"].copy()
    # Normalize outcome names too (they're the team name, same aliases apply)
    h2h["outcome_abbr"] = h2h["outcome"].apply(normalize_team)

    return h2h


def merge_games_and_odds(games: pd.DataFrame,
                         odds: pd.DataFrame) -> pd.DataFrame:
    """
    Attach median-across-books home + away closing moneyline prices to each
    game row, keyed on (home_team, away_team, game_date).
    """
    if games.empty or odds.empty:
        return games

    g = games.copy()
    g["game_date_only"] = pd.to_datetime(g["game_date"]).dt.date

    # Median price per (home, away, date, outcome)
    med = (odds.groupby(["home_team_abbr", "away_team_abbr",
                         "commence_date", "outcome_abbr"])["price"]
           .median().reset_index())
    # Pivot so each game has home_odds and away_odds columns
    wide = med.pivot_table(
        index=["home_team_abbr", "away_team_abbr", "commence_date"],
        columns="outcome_abbr", values="price", aggfunc="first"
    ).reset_index()

    # For each game row, look up home team's price and away team's price
    def _look(row):
        m = wide[
            (wide["home_team_abbr"] == row["home_team"]) &
            (wide["away_team_abbr"] == row["away_team"]) &
            (wide["commence_date"] == row["game_date_only"])
        ]
        if m.empty:
            return pd.Series({"home_price": np.nan, "away_price": np.nan})
        r = m.iloc[0]
        return pd.Series({
            "home_price": r.get(row["home_team"], np.nan),
            "away_price": r.get(row["away_team"], np.nan),
        })

    g[["home_price", "away_price"]] = g.apply(_look, axis=1)
    return g.drop(columns=["game_date_only"])
