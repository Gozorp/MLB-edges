"""
edge_calculator.py
------------------
Turn model probabilities + Vegas odds into actionable bet recommendations.

Pipeline per game:
  1. Devig Vegas odds (Shin) -> fair implied probabilities
  2. Compute EV edge = model_prob - fair_implied
  3. Apply v12-CONVICTION filter based on independent signal convergence
  4. Size with fractional Kelly, clamped by the daily risk cap

The conviction filter is intentionally strict. Backtests have shown that
edge-only betting (ignoring the convergence check) underperforms because
gradient-boosted models surface lots of small, noisy edges. Requiring
multi-signal agreement removes the noise.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from .config import (
    CONVICTION,
    KELLY_FRACTION,
    MAX_DAILY_RISK_UNITS,
    MAX_MODEL_PROB,
    MIN_EDGE_PCT,
    MIN_MODEL_PROB,
    TIER_SIZES,
)
from .market_analysis import american_to_implied, shin

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Core math
# ---------------------------------------------------------------------------
def american_to_decimal(odds: float) -> float:
    """American to decimal odds (b+1 form where b = profit per $1 staked)."""
    if pd.isna(odds):
        return np.nan
    return 1 + (odds / 100.0 if odds > 0 else 100.0 / (-odds))


def expected_value(prob: float, decimal_odds: float) -> float:
    """EV per $1 risked. Positive = +EV."""
    if pd.isna(prob) or pd.isna(decimal_odds):
        return np.nan
    return prob * (decimal_odds - 1) - (1 - prob)


def kelly_stake(prob: float, decimal_odds: float,
                fraction: float = KELLY_FRACTION,
                max_stake: float = 0.05) -> float:
    """
    Fractional Kelly as share of bankroll. Clamped at max_stake to avoid
    concentration from occasional model probability spikes.
    """
    if pd.isna(prob) or pd.isna(decimal_odds) or decimal_odds <= 1:
        return 0.0
    b = decimal_odds - 1
    raw = (b * prob - (1 - prob)) / b
    if raw <= 0:
        return 0.0
    return float(min(fraction * raw, max_stake))


# ---------------------------------------------------------------------------
# Conviction filter (v12-CONVICTION)
# ---------------------------------------------------------------------------
@dataclass
class ConvictionResult:
    tier: str
    primary_score: int
    signals_fired: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


def score_conviction(row: pd.Series) -> ConvictionResult:
    """
    Evaluate the 4 independent signals described in the project memory:
      F1: SP xERA gap      >= CONVICTION.xera_gap_min
      F2: team xwOBA gap   >= CONVICTION.xwoba_gap_min
      F3: swing-take gap   >= CONVICTION.swing_take_gap_min
      F4: pitcher luck     <= CONVICTION.pitcher_luck_max (our SP unlucky)

    Tiering:
      3+ signals fired -> DIAMOND
      2 signals fired  -> PLATINUM
      1 signal AND it's F4 -> GOLD  (luck plays are smaller by default)
      otherwise -> SKIP
    """
    signals: List[str] = []
    notes: List[str] = []

    # F1 - SP xERA gap
    xera = row.get("sp_xera_gap", np.nan)
    if pd.notna(xera) and xera >= CONVICTION.xera_gap_min:
        signals.append(f"F1_xera_gap={xera:.2f}")
    elif pd.notna(xera) and xera <= -CONVICTION.xera_gap_min:
        notes.append(f"F1 negative ({xera:.2f}) — fade side")

    # F2 - team xwOBA gap
    xwoba = row.get("team_woba_gap", np.nan)
    if pd.notna(xwoba) and xwoba >= CONVICTION.xwoba_gap_min:
        signals.append(f"F2_xwoba_gap={xwoba:.3f}")

    # F3 - swing/take run value gap
    stake_gap = row.get("swing_take_gap", np.nan)
    if pd.notna(stake_gap) and stake_gap >= CONVICTION.swing_take_gap_min:
        signals.append(f"F3_swing_take_gap={stake_gap:.1f}")

    # F4 - pitcher luck (ERA - xERA); negative = lucky = regression against OPPOSING SP helps us
    # We check: our SP unlucky (due to improve) OR opp SP lucky (due to regress).
    our_luck = row.get("home_sp_luck", np.nan)  # ERA - xERA for our SP
    opp_luck = row.get("away_sp_luck", np.nan)
    f4_fired = False
    if pd.notna(our_luck) and our_luck >= -CONVICTION.pitcher_luck_max:
        # Our SP's ERA is higher than xERA by at least 1.0 — due to improve.
        signals.append(f"F4_our_sp_unlucky={our_luck:.2f}")
        f4_fired = True
    if pd.notna(opp_luck) and opp_luck <= CONVICTION.pitcher_luck_max:
        signals.append(f"F4_opp_sp_lucky={opp_luck:.2f}")
        f4_fired = True

    primary_score = len([s for s in signals if not s.startswith("F4_") or len(signals) == 1])
    # Count unique signal families for tiering (F1/F2/F3/F4)
    fired_families = {s.split("_")[0] for s in signals}

    if len(fired_families) >= 3:
        tier = "DIAMOND"
    elif len(fired_families) == 2:
        tier = "PLATINUM"
    elif len(fired_families) == 1 and f4_fired:
        tier = "GOLD"
    else:
        tier = "SKIP"

    return ConvictionResult(tier=tier,
                            primary_score=len(fired_families),
                            signals_fired=signals,
                            notes=notes)


# ---------------------------------------------------------------------------
# Per-slate recommender
# ---------------------------------------------------------------------------
def recommend_slate(games: pd.DataFrame,
                    odds: pd.DataFrame,
                    bankroll: float = 100.0) -> pd.DataFrame:
    """
    Merge games (with model_prob) + odds and produce a bet sheet.

    games schema needed:
        game_id, home_team, away_team, model_prob, sp_xera_gap, team_woba_gap,
        swing_take_gap, home_sp_luck, away_sp_luck
    odds schema needed (long form, one row per side):
        game_id, outcome (home/away team name), price (American), market='h2h'
    """
    h2h = odds[odds["market"] == "h2h"].copy()
    # Pivot to wide (home_odds, away_odds) per game_id
    pivot = (h2h.pivot_table(index="game_id", columns="outcome",
                             values="price", aggfunc="median")
             .reset_index())
    merged = games.merge(pivot, on="game_id", how="left", suffixes=("", "_odds"))

    recs = []
    total_risk = 0.0

    for _, r in merged.sort_values("model_prob", ascending=False).iterrows():
        home_odds = r.get(r["home_team"])
        away_odds = r.get(r["away_team"])
        if pd.isna(home_odds) or pd.isna(away_odds):
            continue

        # Devig
        p_home_raw = american_to_implied(home_odds)
        p_away_raw = american_to_implied(away_odds)
        p_home_fair, p_away_fair = shin(p_home_raw, p_away_raw)

        # Choose the side where the model favors
        model_p = r["model_prob"]
        if model_p >= 0.5:
            side, price, fair, p_model = "home", home_odds, p_home_fair, model_p
            team = r["home_team"]
        else:
            side, price, fair, p_model = "away", away_odds, p_away_fair, 1 - model_p
            team = r["away_team"]

        if not (MIN_MODEL_PROB <= p_model <= MAX_MODEL_PROB):
            continue

        dec = american_to_decimal(price)
        ev = expected_value(p_model, dec)
        edge = p_model - (fair if pd.notna(fair) else np.nan)

        if pd.isna(edge) or edge < MIN_EDGE_PCT:
            continue

        # v12-CONVICTION gate — build the row-perspective for the chosen side
        perspective = r.copy()
        if side == "away":
            # Flip gap-signed features so "positive = our edge"
            for col in ["sp_xera_gap", "team_woba_gap", "sp_k_bb_pct_gap",
                        "sp_siera_gap", "sp_fip_gap"]:
                if col in perspective:
                    perspective[col] = -perspective[col]
            # Swap luck perspective
            perspective["home_sp_luck"], perspective["away_sp_luck"] = (
                perspective.get("away_sp_luck"), perspective.get("home_sp_luck"),
            )

        conviction = score_conviction(perspective)
        size_mult = TIER_SIZES[conviction.tier]
        if size_mult == 0:
            continue

        stake_frac = kelly_stake(p_model, dec) * size_mult
        stake_units = stake_frac * bankroll

        # Enforce daily risk cap
        if total_risk + stake_units > MAX_DAILY_RISK_UNITS:
            stake_units = max(0.0, MAX_DAILY_RISK_UNITS - total_risk)
            if stake_units <= 0:
                break

        total_risk += stake_units

        recs.append({
            "game_id": r["game_id"],
            "team":    team,
            "side":    side,
            "price":   price,
            "decimal": round(dec, 3),
            "model_prob": round(p_model, 4),
            "fair_prob":  round(fair, 4) if pd.notna(fair) else np.nan,
            "edge_pp":   round(edge * 100, 2),
            "ev_per_$1": round(ev, 4),
            "tier":      conviction.tier,
            "signals":   ", ".join(conviction.signals_fired),
            "stake_u":   round(stake_units, 2),
        })

    out = pd.DataFrame(recs)
    if out.empty:
        log.info("No bets pass the filter today.")
    else:
        log.info("Total risk: %.2f u on %d bets", total_risk, len(out))
    return out
