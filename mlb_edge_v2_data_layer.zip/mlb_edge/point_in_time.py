"""
point_in_time.py
----------------
Compute pitcher and team stats as-of a given date using ONLY games before
that date. This is the leak-prevention layer for backtesting.

The naive approach — "use season-total xERA for every game" — includes games
played AFTER the one being predicted, which cheats. Every cumulative stat
here is computed from pitch-level Statcast data in strict chronological
order with a `.shift(1)` before any aggregation that touches the game's
own date.
"""
from __future__ import annotations

import logging
from functools import lru_cache
from typing import Dict, Optional

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)


# ===========================================================================
# Pitcher stats
# ===========================================================================
def pitcher_as_of(statcast_df: pd.DataFrame,
                  pitcher_id: int,
                  as_of_date: pd.Timestamp,
                  min_pitches: int = 100) -> Dict[str, float]:
    """
    Return a point-in-time stat dict for a pitcher.

    Pulls all pitches thrown by `pitcher_id` on games with game_date STRICTLY
    BEFORE `as_of_date`, then rolls up the canonical metrics we need.

    Required Statcast columns:
        pitcher, game_date, events, description, estimated_woba_using_speedangle,
        estimated_ba_using_speedangle, launch_speed, launch_angle,
        woba_value, woba_denom, babip_value
    """
    df = statcast_df[
        (statcast_df["pitcher"] == pitcher_id) &
        (pd.to_datetime(statcast_df["game_date"]) < pd.Timestamp(as_of_date))
    ]
    if len(df) < min_pitches:
        return _nan_pitcher_dict()

    # xwOBA allowed (weighted on-base)
    xwoba_num = df["estimated_woba_using_speedangle"].fillna(0).sum()
    xwoba_den = df["woba_denom"].fillna(0).sum()
    xwoba_allowed = xwoba_num / xwoba_den if xwoba_den > 0 else np.nan

    # K and BB rates
    # Strikeouts in Statcast appear as events=='strikeout'
    pa = df[df["events"].notna()]
    n_pa = len(pa)
    if n_pa == 0:
        return _nan_pitcher_dict()
    k_rate = (pa["events"] == "strikeout").sum() / n_pa
    bb_rate = (pa["events"] == "walk").sum() / n_pa
    k_bb_pct = (k_rate - bb_rate) * 100.0

    # xERA proxy: linear transform of xwOBA allowed. The canonical mapping
    # (Savant): xERA ≈ -12.5 + 45 * xwOBA_allowed. This is the standard
    # league-wide approximation Baseball Savant uses for pitcher xERA.
    xera = -12.5 + 45.0 * xwoba_allowed if pd.notna(xwoba_allowed) else np.nan

    # Hard-hit rate (EV >= 95 on batted balls)
    bip = df.dropna(subset=["launch_speed"])
    if len(bip) > 0:
        hardhit_pct = (bip["launch_speed"] >= 95).mean() * 100.0
    else:
        hardhit_pct = np.nan

    # FIP & SIERA approximations from Statcast (full formulas need league constants
    # and HR/9, BB/9, K/9 which require IP. We approximate: use season FG estimate
    # if available, else fall back to xERA as a proxy.)
    # For this backtest, sub-stats are acceptable proxies; gradient boosting picks
    # up the signal from xERA and K-BB% regardless.

    # Recent-form xFIP proxy: xERA over the most recent 30 days
    recent_cutoff = pd.Timestamp(as_of_date) - pd.Timedelta(days=30)
    recent = df[pd.to_datetime(df["game_date"]) >= recent_cutoff]
    if len(recent) >= 50:
        r_xwoba_num = recent["estimated_woba_using_speedangle"].fillna(0).sum()
        r_xwoba_den = recent["woba_denom"].fillna(0).sum()
        r_xwoba = r_xwoba_num / r_xwoba_den if r_xwoba_den > 0 else np.nan
        recent_xfip = -12.5 + 45.0 * r_xwoba if pd.notna(r_xwoba) else np.nan
    else:
        recent_xfip = xera  # fall back to season

    # IP per start: from number of distinct games started
    games = df.groupby("game_date").size()
    ip_per_start = (len(df) / 15.0) / max(len(games), 1)  # ~15 pitches per inning
    # (This is approximate — for a precise value we'd parse inning transitions.)

    # ERA - xERA gap (luck flag). Compute ERA from earned runs / IP.
    # Statcast doesn't give clean earned runs per-pitch. We approximate by
    # looking at woba_value (which contains run expectancy) aggregated.
    era_proxy = _approximate_era(df)
    era_xera_gap = era_proxy - xera if pd.notna(era_proxy) and pd.notna(xera) else np.nan

    return {
        "sp_xera":                xera,
        "sp_xwoba_allowed":       xwoba_allowed,
        "sp_k_bb_pct":            k_bb_pct,
        "sp_k_pct":               k_rate * 100,
        "sp_bb_pct":              bb_rate * 100,
        "sp_hardhit_pct_allowed": hardhit_pct,
        "sp_siera":               xera,  # proxy
        "sp_fip":                 xera,  # proxy
        "sp_recent_xfip":         recent_xfip,
        "sp_ip_per_start":        ip_per_start,
        "sp_era_xera_gap":        era_xera_gap,  # positive = unlucky, due for improvement
        "sp_n_pitches":           len(df),
    }


def _nan_pitcher_dict() -> Dict[str, float]:
    return {k: np.nan for k in [
        "sp_xera", "sp_xwoba_allowed", "sp_k_bb_pct", "sp_k_pct", "sp_bb_pct",
        "sp_hardhit_pct_allowed", "sp_siera", "sp_fip", "sp_recent_xfip",
        "sp_ip_per_start", "sp_era_xera_gap", "sp_n_pitches",
    ]}


def _approximate_era(df: pd.DataFrame) -> float:
    """
    Rough ERA from pitch-level Statcast. Uses the `bat_score` and `fld_score`
    progression to count earned runs; divides by approximate innings (outs/3).
    """
    # Outs from events that record an out
    outs_events = {
        "field_out", "force_out", "sac_fly", "sac_bunt", "grounded_into_double_play",
        "double_play", "triple_play", "strikeout", "strikeout_double_play",
        "caught_stealing_2b", "caught_stealing_3b", "caught_stealing_home",
        "pickoff_1b", "pickoff_2b", "pickoff_3b", "fielders_choice_out",
        "other_out",
    }
    outs = df[df["events"].isin(outs_events)]
    n_outs = len(outs)
    if "grounded_into_double_play" in df["events"].values:
        n_outs += (df["events"] == "grounded_into_double_play").sum()
    ip = n_outs / 3.0
    if ip < 5:
        return np.nan

    # Runs charged to this pitcher — approximation using delta_score
    # For simplicity, count runs scored in innings this pitcher appeared.
    # (A fully accurate ERA needs pitcher-of-record logic which Statcast
    # doesn't expose directly.)
    if "post_bat_score" in df.columns and "bat_score" in df.columns:
        runs = (df["post_bat_score"].fillna(0) - df["bat_score"].fillna(0)).clip(lower=0).sum()
    else:
        runs = np.nan
    if pd.isna(runs):
        return np.nan
    return 9.0 * runs / ip


# ===========================================================================
# Team offensive stats
# ===========================================================================
def team_batting_as_of(statcast_df: pd.DataFrame,
                       team: str,
                       as_of_date: pd.Timestamp,
                       min_pa: int = 200) -> Dict[str, float]:
    """
    Team-level offensive stats as of a date.

    We identify team plate appearances by: (home_team == team AND inning_topbot == 'Bot')
    OR (away_team == team AND inning_topbot == 'Top').

    Required Statcast columns:
        home_team, away_team, inning_topbot, game_date, events,
        estimated_woba_using_speedangle, woba_denom, launch_speed
    """
    is_home_ab = (statcast_df["home_team"] == team) & (statcast_df["inning_topbot"] == "Bot")
    is_away_ab = (statcast_df["away_team"] == team) & (statcast_df["inning_topbot"] == "Top")
    mask = (is_home_ab | is_away_ab) & \
           (pd.to_datetime(statcast_df["game_date"]) < pd.Timestamp(as_of_date))
    df = statcast_df[mask]
    if len(df) < min_pa:
        return _nan_team_dict()

    pa = df[df["events"].notna()]
    n_pa = len(pa)
    if n_pa == 0:
        return _nan_team_dict()

    xwoba_num = df["estimated_woba_using_speedangle"].fillna(0).sum()
    xwoba_den = df["woba_denom"].fillna(0).sum()
    xwoba = xwoba_num / xwoba_den if xwoba_den > 0 else np.nan

    # wOBA (real, not expected) as a reasonable wRC+ proxy — scaled to league
    if "woba_value" in df.columns and "woba_denom" in df.columns:
        woba_num = df["woba_value"].fillna(0).sum()
        woba_real = woba_num / xwoba_den if xwoba_den > 0 else np.nan
    else:
        woba_real = xwoba

    k_rate = (pa["events"] == "strikeout").sum() / n_pa
    bb_rate = (pa["events"] == "walk").sum() / n_pa

    bip = df.dropna(subset=["launch_speed"])
    hardhit_pct = (bip["launch_speed"] >= 95).mean() * 100.0 if len(bip) > 0 else np.nan

    # wRC+ proxy: scale wOBA to league-average (~0.315). 100 = league-avg.
    league_woba = 0.315
    wrc_plus_proxy = 100.0 * (woba_real / league_woba) if pd.notna(woba_real) else np.nan

    # Swing-take run value gap — proxied via xwOBA run expectancy
    # For the full swing/take decomposition, you'd need pitch-zone data.
    # We use (xwoba - league_avg) * n_pa * some_scale as a proxy signal.
    swing_take_proxy = (xwoba - league_woba) * n_pa * 100.0 if pd.notna(xwoba) else np.nan

    return {
        "team_wrc_plus":    wrc_plus_proxy,
        "team_xwoba":       xwoba,
        "team_woba":        woba_real,
        "team_k_pct":       k_rate * 100,
        "team_bb_pct":      bb_rate * 100,
        "team_hardhit_pct": hardhit_pct,
        "team_swing_take":  swing_take_proxy,
        "team_n_pa":        n_pa,
    }


def _nan_team_dict() -> Dict[str, float]:
    return {k: np.nan for k in [
        "team_wrc_plus", "team_xwoba", "team_woba", "team_k_pct",
        "team_bb_pct", "team_hardhit_pct", "team_swing_take", "team_n_pa",
    ]}


# ===========================================================================
# Bullpen aggregate
# ===========================================================================
def bullpen_as_of(statcast_df: pd.DataFrame,
                  team: str,
                  as_of_date: pd.Timestamp,
                  starter_ids_by_team: Dict[str, set],
                  min_pitches: int = 200) -> Dict[str, float]:
    """
    Aggregate bullpen stats = everyone pitching for `team` who isn't a
    known starter. Uses `starter_ids_by_team` to filter out SPs.
    """
    mask = (
        (statcast_df[["home_team", "away_team"]].eq(team).any(axis=1)) &
        (pd.to_datetime(statcast_df["game_date"]) < pd.Timestamp(as_of_date))
    )
    df = statcast_df[mask].copy()

    # Pitches thrown by this team = (team == home_team AND inning_topbot == 'Top')
    #                            or (team == away_team AND inning_topbot == 'Bot')
    is_home_pitch = (df["home_team"] == team) & (df["inning_topbot"] == "Top")
    is_away_pitch = (df["away_team"] == team) & (df["inning_topbot"] == "Bot")
    df = df[is_home_pitch | is_away_pitch]

    starters = starter_ids_by_team.get(team, set())
    bp = df[~df["pitcher"].isin(starters)]
    if len(bp) < min_pitches:
        return {"bullpen_xera": np.nan, "bullpen_xwoba": np.nan, "bullpen_n_pitches": len(bp)}

    xwoba_num = bp["estimated_woba_using_speedangle"].fillna(0).sum()
    xwoba_den = bp["woba_denom"].fillna(0).sum()
    xwoba = xwoba_num / xwoba_den if xwoba_den > 0 else np.nan
    xera = -12.5 + 45.0 * xwoba if pd.notna(xwoba) else np.nan

    return {
        "bullpen_xera": xera,
        "bullpen_xwoba": xwoba,
        "bullpen_n_pitches": len(bp),
    }


# ===========================================================================
# Bullpen fatigue
# ===========================================================================
def bullpen_fatigue_as_of(statcast_df: pd.DataFrame,
                          team: str,
                          as_of_date: pd.Timestamp,
                          starter_ids_by_team: Dict[str, set],
                          lookback_days: int = 3) -> float:
    """
    Fatigue score ∈ [0, 1] based on bullpen usage in last `lookback_days`.
    Simple rule: count pitches thrown by non-starter pitchers for this team
    in the window; normalize so 300+ pitches = 1.0.
    """
    cutoff_hi = pd.Timestamp(as_of_date)
    cutoff_lo = cutoff_hi - pd.Timedelta(days=lookback_days)
    mask = (
        (pd.to_datetime(statcast_df["game_date"]) >= cutoff_lo) &
        (pd.to_datetime(statcast_df["game_date"]) < cutoff_hi) &
        (statcast_df[["home_team", "away_team"]].eq(team).any(axis=1))
    )
    df = statcast_df[mask]
    is_home_pitch = (df["home_team"] == team) & (df["inning_topbot"] == "Top")
    is_away_pitch = (df["away_team"] == team) & (df["inning_topbot"] == "Bot")
    df = df[is_home_pitch | is_away_pitch]
    starters = starter_ids_by_team.get(team, set())
    bp_pitches = df[~df["pitcher"].isin(starters)]
    return float(min(len(bp_pitches) / 300.0, 1.0))


# ===========================================================================
# Starter identification
# ===========================================================================
def infer_starters_by_team(statcast_df: pd.DataFrame) -> Dict[str, set]:
    """
    Infer each team's starting pitchers from Statcast by finding pitchers
    who threw the first pitch of a game (inning==1, outs==0, early in the
    plate appearance).

    Returns {team_abbrev: set(pitcher_ids)}.
    """
    first_pitches = statcast_df[
        (statcast_df["inning"] == 1) &
        (statcast_df["outs_when_up"] == 0)
    ].drop_duplicates(subset=["game_pk", "inning_topbot"])

    result: Dict[str, set] = {}
    for _, row in first_pitches.iterrows():
        # Top of 1 = away batting, home team's pitcher on mound
        if row["inning_topbot"] == "Top":
            team = row["home_team"]
        else:
            team = row["away_team"]
        result.setdefault(team, set()).add(row["pitcher"])
    return result


def get_game_starters(statcast_df: pd.DataFrame,
                      game_pk: int) -> Dict[str, Optional[int]]:
    """Return {'home_sp': pitcher_id, 'away_sp': pitcher_id} for a game_pk."""
    game = statcast_df[statcast_df["game_pk"] == game_pk]
    if game.empty:
        return {"home_sp": None, "away_sp": None}

    first_inn = game[(game["inning"] == 1) & (game["outs_when_up"] == 0)]
    home_sp = None
    away_sp = None
    top1 = first_inn[first_inn["inning_topbot"] == "Top"]
    bot1 = first_inn[first_inn["inning_topbot"] == "Bot"]
    if not top1.empty:
        home_sp = int(top1.iloc[0]["pitcher"])  # home pitcher throws in top of 1
    if not bot1.empty:
        away_sp = int(bot1.iloc[0]["pitcher"])

    return {"home_sp": home_sp, "away_sp": away_sp}
